require('dotenv').config(); 
const db=require('../models/db');
const jwt=require('jsonwebtoken');
const bcrypt=require('bcrypt')
const saltRounds=10;
const secret_key = process.env.SECRET_KEY;

async function registeruser(FirstName, LastName,phone_number, email,pincode,location,password,profile_picture, roles) {
    const checkQuery = 'SELECT COUNT(*) AS count FROM Users WHERE email = ?';
    const salt = await bcrypt.genSalt(saltRounds);
    const hashedPassword = await bcrypt.hash(password, salt);

    const insertQuery = 'INSERT INTO Users (FirstName, LastName,phone_number, email,pincode,location,password,profile_picture, roles) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)';

    try {
        // Check if the user already exists
        const [checkResult] = await db.query(checkQuery, [email]);
        if (checkResult[0].count > 0) {
            throw new Error('Email already exists');
        }

        // Insert the new user into the database
        const [insertResult] = await db.query(insertQuery, [FirstName, LastName,phone_number, email,pincode,location,hashedPassword,profile_picture, roles]);
        
        return { id: insertResult.insertId, message: 'User registered successfully' };
    } catch (err) {
        throw new Error('Error registering user: ' + err.message);
    }
}

  async function loginuser(email, password) {
    const query = 'SELECT user_id, email, password FROM Users WHERE email = ?';
    
    try {
        const [rows] = await db.query(query, [email]);
        if (rows.length === 0) {
            throw new Error('User does not exist');
        }

        const user = rows[0];
        const isMatch = await bcrypt.compare(password, user.password);

        if (isMatch) {
            const token = jwt.sign(
                { user: { id: user.UserId, email: user.email } },
                secret_key,
                { expiresIn: '1h' }
            );

            return { token, message: 'Login successful' };
        } else {
            throw new Error('Invalid password or email');
        }
    } catch (err) {
        console.error('Error during login:', err.message);
        throw new Error('Error during login: ' + err.message);
    }
}

async function getAgentsByLocation(location) {
    const agentsQuery = 'SELECT FirstName, LastName, email, phone_number FROM Users WHERE location = ? AND roles = "Agent"';

    try {
        // Retrieve agents from the specified city
        const [agentsResult] = await db.query(agentsQuery, [location]);

        return agentsResult;
    } catch (err) {
        // Handle errors and log them if necessary
        console.error('Error retrieving agents:', err);
        throw new Error('Error retrieving agents: ' + err.message);
    }
}

// post wishlist
// async function addToWishlist(user_id, property_id) {
//     const query = 'INSERT INTO Wishlist (user_id, property_id) VALUES (?, ?)';
//     try {
//         const [result] = await db.query(query, [user_id, property_id]);
//         return { wishlist_id: result.insertId, message: 'Item added to wishlist successfully' };
//     } catch (error) {
//         throw new Error('Error adding item to wishlist: ' + error.message);
//     }
// }

async function addToWishlist(user_id, property_id) {
    const checkPropertyQuery = 'SELECT COUNT(*) AS count FROM Properties WHERE property_id = ?';
    const insertQuery = 'INSERT INTO Wishlist (user_id, property_id) VALUES (?, ?)';
    
    try {
        // Check if the property exists
        const [propertyCheckResult] = await db.query(checkPropertyQuery, [property_id]);
        if (propertyCheckResult[0].count === 0) {
            throw new Error('Property does not exist');
        }

        // Insert the new item into the wishlist
        const [result] = await db.query(insertQuery, [user_id, property_id]);
        return { wishlist_id: result.insertId, message: 'Item added to wishlist successfully' };
    } catch (error) {
        throw new Error('Error adding item to wishlist: ' + error.message);
    }
}

// async function getWishlistItems() {
//     const query = 'SELECT * FROM Wishlist';
//     try {
//         const [wishlistResult] = await db.query(query)

//         return wishlistResult;
//     } catch(err) {
//         console.error('Error while retrving wishlist items: ', err);
//         throw new Error('Error while retrving wishlist items: ', err.message);
//     }
// }

// async function getWishListByUser(user_id) {
//     const query = 'SELECT * FROM Wishlist WHERE user_id = ?';
//     try {
//         const [getWishListByUserResult] = await db.query(query,[user_id]);
//         return getWishListByUserResult
//     } catch(err) {
//         console.error('Error while retrving wishlist items: ', err);
//         throw new Error('Error while retrving wishlist items: ', err.message);
//     }
// }
// Function to get wishlist items by user_id
async function getWishlistByUser(user_id) {
    const query = 
    `   SELECT 
            Properties.property_id,
            Properties.title,
            Properties.location,
            Properties.images
        FROM 
            Wishlist
        INNER JOIN 
            Properties 
        ON 
            Wishlist.property_id = Properties.property_id
        WHERE 
            Wishlist.user_id = ?;
    `;
    
    try {
        const [wishlistResult] = await db.query(query, [user_id]);
        return wishlistResult;
    } catch (err) {
        throw new Error('Error retrieving wishlist items: ' + err.message);
    }
}
async function createProperty(propertyData) {
    const {
        user_id,
        title,
        description,
        address,
        location,
        state,
        pincode,
        price,
        type,
        status,
        square_feet,
        images  // Assume images is now an array
    } = propertyData;

    try {
        // Convert images array to JSON string
        const imagesJson = JSON.stringify(images);

        const [result] = await db.query(
            `INSERT INTO Properties 
            (user_id, title, description, address, location, state, pincode, price, type, status, square_feet, images)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [user_id, title, description, JSON.stringify(address), location, state, pincode, price, type, status, square_feet, imagesJson]
        );
        return result;
    } catch (error) {
        throw error;
    }
}
// get by filters
async function getPropertiesByFilters(filters) {
    let query = 'SELECT * FROM Properties WHERE 1=1'; // Start with a base query
    const queryParams = [];

    // Apply filters based on exact matches
    if (filters.type) {
        query += ' AND type = ?';
        queryParams.push(filters.type);
    }

    if (filters.price) {
        query += ' AND price = ?';
        queryParams.push(filters.price);
    }

    if (filters.location) {
        query += ' AND location = ?';
        queryParams.push(filters.location);
    }

    if (filters.squareFeet) {
        query += ' AND square_feet = ?';
        queryParams.push(filters.squareFeet);
    }

    try {
        const [result] = await db.query(query, queryParams);
        return result;
    } catch (error) {
        throw new Error('Error retrieving properties: ' + error.message);
    }
}
async function getAllProperties() {
    try {
        const [rows] = await db.query(`SELECT * FROM Properties`);
        return rows;
    } catch (error) {
        throw error;
    }
}


// Function to get properties by budget or price range
async function getPropertiesByPrice(price) {
    const query = 'SELECT * FROM Properties WHERE price <= ?';
    
    try {
        const [result] = await db.query(query, [price]);
        return result;
    } catch (error) {
        throw new Error('Error retrieving properties by price: ' + error.message);
    }
}

// Function to get property details by ID
async function getPropertyById(propertyId) {
    const query = 'SELECT * FROM Properties WHERE property_id = ?';
    try {
        const [result] = await db.query(query, [propertyId]);
        return result;
    } catch (error) {
        throw new Error('Error retrieving property details: ' + error.message);
    }
}



async function createBooking(bookingData) {
    const {
        booking_id,
        property_id,
        user_id,
        agent_id,
        // seller_id,
        appointment_date,
        appointment_time,
        status,
        location
    } = bookingData;
// add seller id
    try {
        const [result] = await db.query(
            `INSERT INTO Booking 
            (booking_id, property_id, user_id, agent_id, 
             appointment_date, appointment_time, status, location)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [booking_id, property_id, user_id, agent_id, appointment_date, appointment_time, status, location]
        );
        return result;
    } catch (error) {
        throw error;
    }
}

async function getBookingById(booking_id) {
    const query = 'SELECT * FROM Booking WHERE booking_id = ?';
    try {
        const [bookingResult] = await db.query(query, [booking_id]);
        return bookingResult;
    } catch (error) {
        throw new Error('Error retrieving booking details: ' + error.message);
    }
}


// module.exports = { registeruser, loginuser, getAgentsByLocation, getWishlistItems, getWishListByUser, createProperty, getAllProperties, createBooking };

module.exports = { getBookingById,registeruser, loginuser ,getAgentsByLocation, createProperty,getAllProperties,
    getPropertiesByPrice, getWishlistByUser,
    getPropertyById ,createBooking, addToWishlist ,getPropertiesByFilters,
};